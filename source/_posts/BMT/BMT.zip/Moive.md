---
title: 电影记录
date: 2020-10-28 21:53:04
updated: 
categories:
- 书影音
- 电影
tags: 
- 电影
- 影评
password: moviecyc
abstract: 记录看过的电影，评分，评论等。(暂时加密)
top: 50
---
>记录看过的电影，评分，评论等。

<!--less-->

